<?php
/**
 * @author Mailjet SAS
 *
 * @copyright  Copyright (C) 2014 Mailjet SAS.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */
defined('_JEXEC') or die();

if (!defined('DS')) {
  define('DS',DIRECTORY_SEPARATOR);
}

jimport('joomla.application.component.model');

if (!function_exists('class_alias')) { // For php older then 5.3
  function class_alias($orig, $alias) {
    eval('abstract class ' . $alias . ' extends ' . $orig . ' {}');
  }
}

if (!class_exists('JModelLegacy')) {
  class_alias('JModel','JModelLegacy');
}

/* Require the Mailjet API library */
require_once (sPrintF ('%s/components/com_mailjet/lib/lib/mailjet-api-strategy.php', JPATH_ADMINISTRATOR));

class MailjetModelMailjet extends JModelLegacy {

    protected $api;
    protected $params;

    function __construct()
    {
        parent::__construct();
        $this->params = $this->getAsRecord();
        $this->api = new Mailjet_Api($this->params['username'], $this->params['password']);				
    }
	
    function store(){
    	// Get the data which we'll save
        $email = filter_var($_POST['mailjet-email'], FILTER_SANITIZE_EMAIL);
        $list_id = filter_var($_POST['mailjet-list_id'], FILTER_SANITIZE_NUMBER_INT);
        if (empty($email)) $email = filter_var($_GET['mailjet-email'], FILTER_SANITIZE_EMAIL);
        if (empty($list_id)) $list_id = filter_var($_GET['mailjet-list_id'], FILTER_SANITIZE_NUMBER_INT);
        if ((empty($email)) || (empty($list_id))) return false;
	
		// Add the contact to the contact list
        $response = $this->api->addContact(array(
            'Email' => $email,
            'ListID' => $list_id
        ));

        if (isset($response->Status) && $response->Status == 'OK') {
            return true;
        }
        if (isset($response->Status) && $response->Status == 'DUPLICATE') {
            return 'DUPLICATE';
        }
        return false;
        $status = false;
	if(isset($response->Status)){
            switch($response->Status){
                case 'OK':
                    $status = true;
                    break;
                case $status = 'DUPLICATE';
                    break;
            }
        }
        return $status;
    }

    public function getAsRecord ()
    {
        //Below are some comments containing error messages to improve usability
        $credentials = sPrintF ('%s/components/%s/lib/db/data', JPATH_ADMINISTRATOR, 'com_mailjet');

        if(file_exists($credentials)){
            
            $pre_data = null;
            $content = trim(file_get_contents($credentials));
            
            if ($content) {
                $pre_data = json_decode($content);
            }

            /*if(!$pre_data->apiKey || !$pre_data->apiSecret){
                JError::raiseWarning( 100, JText::_("COM_MAILJET_INCOMPLETE_INFO") );
            }*/

            $data ['username'] = $pre_data->apiKey;
            $data ['password'] = $pre_data->apiSecret;

            return $data;
		}
        /*else{
            JError::raiseWarning( 100, JText::_("COM_MAILJET_NO_DATAFILE") );
        }*/
    }
}
