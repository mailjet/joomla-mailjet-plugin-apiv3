<?php
class JMailjetConfig {
	public $bak_mailer = "smtp";
	public $bak_smtpauth = "1";
	public $bak_smtpuser = "your API key";
	public $bak_smtppass = "your API secret";
	public $bak_smtphost = "in.mailjet.com";
	public $bak_smtpsecure = "tls";
	public $bak_smtpport = "587";
	public $enable = "";
	public $test = "";
	public $test_address = "test@emailaddress";
	public $username = "6363e9d3b0fbcc689c98e18a1a0ba9b5";
	public $password = "ea3818da6ef29051a081297d4e4ea6cb";
	public $host = "in.mailjet.com";
	public $secure = "tls";
	public $port = "587";
}