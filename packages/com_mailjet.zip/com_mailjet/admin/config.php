<?php
/**
 * @author Mailjet SAS
 *
 * @copyright  Copyright (C) 2014 Mailjet SAS.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class JMailjetConfig {
	public $bak_mailer = 'smtp';
	public $bak_smtpauth = '1';
	public $bak_smtpuser = 'your API key';
	public $bak_smtppass = 'your API secret';
	public $bak_smtphost = 'in-v3.mailjet.com';
	public $bak_smtpsecure = 'tls';
	public $bak_smtpport = '587';
	public $enable = '';
	public $test = '';
	public $test_address = 'test@emailaddress';
	public $username = 'your API key';
	public $password = 'your API secret';
	public $host = 'in-v3.mailjet.com';
	public $secure = 'tls';
	public $port = '587';
}