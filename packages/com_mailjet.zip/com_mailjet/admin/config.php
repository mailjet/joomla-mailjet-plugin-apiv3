<?php

class JMailjetConfig
{
    public $bak_mailer = "smtp";
    public $bak_smtpauth = "1";
    public $bak_smtpuser = "your API key";
    public $bak_smtppass = "your API secret";
    public $bak_smtphost = "in-v3.mailjet.com";
    public $bak_smtpsecure = "tls";
    public $bak_smtpport = "587";
    public $enable = "";
    public $test = "";
    public $test_address = "test@emailaddress";
    public $username = "";
    public $password = "";
    public $host = "in-v3.mailjet.com";
    public $secure = "tls";
    public $port = "587";
}